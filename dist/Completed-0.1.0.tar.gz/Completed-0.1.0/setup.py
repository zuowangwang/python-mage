from distutils.core import  setup

setup(name = 'Completed',
      version ='0.1.0',
      description = 'Completed Utilities',
      author = 'zuo' ,
      author_email = 'zuo@qq.com',
      url = 'http://www.baidu.com',
      packages = ['mag363','mag363.Completed'],
      )



